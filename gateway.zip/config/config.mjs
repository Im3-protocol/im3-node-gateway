export const API_KEY = 'your_api_key';
export const API_SECRET = 'your_api_secret';
export const LIVEKIT_HOST = 'meet.im3.live';
